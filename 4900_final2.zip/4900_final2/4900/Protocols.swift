//
//  Protocols.swift
//  4900
//
//  Created by leo  luo on 2017-05-20.
//  Copyright © 2017 leo  luo. All rights reserved.
//

protocol SaveDataProtocol {
    func saveData()
}
